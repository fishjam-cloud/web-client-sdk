/**
 * Initialize the background blur processor with ExecuTorch segmentation model.
 * Must be called before using the blur middleware.
 * @param modelPath Path to the .pte segmentation model file
 * @example
 * ```ts
 * import { initializeBackgroundBlur } from '@executorch/react-native-executorch-webrtc';
 *
 * // Initialize with your model
 * initializeBackgroundBlur('/path/to/selfie_segmenter.pte');
 * ```
 */
export declare const initializeBackgroundBlur: (modelPath: string) => void;
/**
 * Deinitialize and release background blur resources.
 * @example
 * ```ts
 * import { deinitializeBackgroundBlur } from '@executorch/react-native-executorch-webrtc';
 *
 * deinitializeBackgroundBlur();
 * ```
 */
export declare const deinitializeBackgroundBlur: () => void;
/**
 * Check if background blur has been initialized
 * @returns Whether background blur is initialized
 */
export declare const isBackgroundBlurInitialized: () => boolean;
//# sourceMappingURL=BackgroundBlur.d.ts.map