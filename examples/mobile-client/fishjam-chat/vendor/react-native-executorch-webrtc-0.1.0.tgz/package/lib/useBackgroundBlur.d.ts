/**
 * Middleware function type compatible with Fishjam SDK
 */
export type TrackMiddleware = (track: MediaStreamTrack) => {
    track: MediaStreamTrack;
    onClear: () => void;
};
/**
 * Options for useBackgroundBlur hook
 */
export type UseBackgroundBlurOptions = {
    /**
     * Path to the ExecuTorch segmentation model (.pte file)
     * Required for initialization
     */
    modelUri: string;
    /**
     * Blur intensity/radius (default: 12)
     */
    blurRadius?: number;
};
/**
 * Hook to enable background blur on WebRTC video tracks.
 * Compatible with Fishjam SDK's TrackMiddleware interface.
 * @param options Configuration options including model path and blur radius
 * @returns Object containing blurMiddleware for use with Fishjam SDK
 * @example
 * ```tsx
 * import { useBackgroundBlur } from '@executorch/react-native-executorch-webrtc';
 *
 * function VideoCall() {
 *   const { blurMiddleware } = useBackgroundBlur({
 *     modelUri: 'file:///path/to/selfie_segmenter.pte',
 *     blurRadius: 15,
 *   });
 *
 *   // Use with Fishjam SDK
 *   const { toggleCamera } = useCamera({
 *     cameraTrackMiddleware: blurMiddleware,
 *   });
 *
 *   // Or use directly with a track
 *   const applyBlur = (track: MediaStreamTrack) => {
 *     const { onClear } = blurMiddleware(track);
 *     // Call onClear() to remove the effect
 *   };
 * }
 * ```
 */
export declare function useBackgroundBlur(options: UseBackgroundBlurOptions): {
    blurMiddleware: TrackMiddleware;
};
//# sourceMappingURL=useBackgroundBlur.d.ts.map