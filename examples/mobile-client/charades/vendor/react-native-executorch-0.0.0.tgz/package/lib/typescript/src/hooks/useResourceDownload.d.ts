/**
 * React hook to manage downloading and local caching of remote resources (e.g.
 * `.pte` models).
 *
 * If the source is a remote URL starting with `http`, the hook checks the local
 * filesystem cache for a matching file. If cached, it immediately returns the
 * local file path. If not cached, it starts downloading the file to the
 * application cache directory, reporting download progress (0-100) and any
 * network/disk errors.
 * @category Hooks
 * @experimental Subject to change once the temporary react-native-fs dependency is replaced.
 * See [Issue #1253](https://github.com/software-mansion/react-native-executorch/issues/1253).
 * @param source The remote URL or local path to the resource. If it's already a
 * local path, it is returned immediately as is.
 * @param preventLoad If true, prevents checks and downloads, resetting the hook
 * state.
 * @returns An object containing the local file path, the download progress
 * percentage, and any download error.
 */
export declare function useResourceDownload(source?: string, preventLoad?: boolean): {
    localPath: string | undefined;
    downloadProgress: number;
    downloadError: Error | null;
};
//# sourceMappingURL=useResourceDownload.d.ts.map