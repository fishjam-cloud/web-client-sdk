import type { WorkletRuntime } from 'react-native-worklets';
import type { ResizeMode } from '../ops/image';
import type { ImageBuffer } from '../image';
import { type ImagePreprocessorOptions } from './preprocessing';
import { type BoundingBox, type BoxFormat } from '../ops/boxes';
export type { BoxFormat };
/**
 * Options for configuring an object detector preprocessor, label vocabulary,
 * and detection thresholds.
 * @category Types
 */
export type ObjectDetectorOptions<F extends BoxFormat, L> = Omit<ImagePreprocessorOptions, 'resizeMode'> & {
    readonly resizeMode: Exclude<ResizeMode, 'crop'>;
    readonly labels: readonly L[];
    readonly boxFormat: F;
    readonly defaultIouThreshold: number;
    readonly defaultConfidenceThreshold: number;
};
/**
 * Model configuration required to instantiate an object detector task runner.
 * @category Types
 */
export type ObjectDetectorModel<F extends BoxFormat, L> = {
    readonly modelPath: string;
    readonly opts: ObjectDetectorOptions<F, L>;
};
/**
 * Result structure representing a single object detection prediction.
 * @category Types
 */
export type ObjectDetection<F extends BoxFormat, L> = {
    readonly box: BoundingBox<F>;
    readonly label: L;
    readonly confidence: number;
};
/**
 * Creates an object detector runner for executing local Object Detection
 * models.
 *
 * It validates the model inputs and outputs requirements, pre-allocates the
 * necessary static execution tensors (boxes, scores, classes), sets up an image
 * preprocessor, and registers clean disposal hooks to clear all native memory.
 * @category Typescript API
 * @typeParam F The bounding box format.
 * @typeParam L The type representing the class labels.
 * @param config Object detector task configuration containing path and options.
 * @param runtime Optional worklet runtime thread on which to run the model
 * execution.
 * @returns A promise resolving to an object containing object detection and
 * disposal controls.
 */
export declare function createObjectDetector<F extends BoxFormat, L>(config: ObjectDetectorModel<F, L>, runtime?: WorkletRuntime): Promise<{
    /**
     * Releases all allocated native resources.
     */
    dispose: () => void;
    /**
     * Performs asynchronous object detection on the given input image.
     * @param input The input image buffer.
     * @param options Configuration options for object detection.
     * @param options.confidenceThreshold Minimum confidence score for returned
     * detections.
     * @param options.iouThreshold Non-maximum suppression IoU threshold.
     * @returns A promise resolving to the list of object detections.
     */
    detectObjects: (input: ImageBuffer, options?: {
        confidenceThreshold?: number;
        iouThreshold?: number;
    }) => Promise<ObjectDetection<F, L>[]>;
    /**
     * Synchronous version of {@link detectObjects} to be executed directly on the
     * caller or worklet thread.
     */
    detectObjectsWorklet: (input: ImageBuffer, options?: {
        confidenceThreshold?: number;
        iouThreshold?: number;
    }) => ObjectDetection<F, L>[];
}>;
//# sourceMappingURL=objectDetection.d.ts.map