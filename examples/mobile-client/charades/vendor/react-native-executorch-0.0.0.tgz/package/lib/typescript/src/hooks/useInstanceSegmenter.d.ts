import { type InstanceSegmenterModel, type BoxFormat } from '../extensions/cv/tasks/instanceSegmentation';
/**
 * React hook to load and run an instance segmentation model.
 *
 * This hook manages downloading (if it's a remote URL) and loading the model
 * file, compiling it, tracking download progress and compilation errors, and
 * cleaning up native model memory when the component unmounts or configuration
 * changes.
 * @category Hooks
 * @typeParam F The bounding box format.
 * @typeParam L The class labels type.
 * @param config The instance segmentation model configuration.
 * @param options Hook options.
 * @param options.preventLoad If true, prevents downloading and compiling the
 * model.
 * @returns An object containing the model's loading state, error, download
 * progress, and segmentation functions.
 */
export declare function useInstanceSegmenter<F extends BoxFormat, L>(config: InstanceSegmenterModel<F, L>, options?: {
    preventLoad?: boolean;
}): {
    isReady: boolean;
    error: Error | null;
    downloadProgress: number;
    localPath: string | undefined;
    segmentInstances: ((input: import("../extensions/cv").ImageBuffer, options?: {
        confidenceThreshold?: number;
        iouThreshold?: number;
        maskThreshold?: number;
    }) => Promise<import("..").InstanceSegmentationResult<F, L>[]>) | undefined;
    segmentInstancesWorklet: ((input: import("../extensions/cv").ImageBuffer, options?: {
        confidenceThreshold?: number;
        iouThreshold?: number;
        maskThreshold?: number;
    }) => import("..").InstanceSegmentationResult<F, L>[]) | undefined;
    labels: readonly L[];
};
//# sourceMappingURL=useInstanceSegmenter.d.ts.map