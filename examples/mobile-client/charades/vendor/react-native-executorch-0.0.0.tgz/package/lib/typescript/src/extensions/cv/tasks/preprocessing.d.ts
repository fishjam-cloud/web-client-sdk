import { type Tensor } from '../../../core/tensor';
import type { ImageBuffer } from '../image';
import { type ResizeMode, type InterpolationMethod } from '../ops/image';
/**
 * Options for configuring the image preprocessor pipeline.
 * @category Types
 */
export type ImagePreprocessorOptions = {
    readonly resizeMode: ResizeMode;
    readonly interpolation: InterpolationMethod;
    readonly alpha: number | readonly number[];
    readonly beta: number | readonly number[];
    readonly padValue?: number;
};
/**
 * Creates a reusable image preprocessor pipeline.
 *
 * Configures a pipeline to resize, color convert, convert layout (HWC to CHW),
 * normalize, and copy raw image buffers into target tensors matching model
 * input shapes. All intermediate scratch tensors are pre-allocated and safely
 * disposed of when calling `dispose()`.
 * @category Typescript API
 * @param opts Normalization scaling coefficients, interpolation algorithms, and
 * crop/resize modes.
 * @param outputShape Expected output shape of the model input tensor (must
 * match `[1, 3, H, W]` or `[3, H, W]`).
 * @returns An object containing the `process` runner function and a `dispose`
 * method.
 */
export declare function createImagePreprocessor(opts: ImagePreprocessorOptions, outputShape: number[]): {
    /**
     * Preprocesses the input image by resizing, converting color space, changing
     * format layout, and normalizing values, copying the output directly to the
     * pre-allocated output tensor.
     *
     * Note: The returned tensor is managed by the preprocessor; consumers do not
     * need to dispose of it manually.
     * @param input The input image buffer to preprocess.
     * @returns A reference to the output tensor containing preprocessed float32
     * data.
     */
    process: (input: ImageBuffer) => Tensor;
    /**
     * Releases all allocated native resources.
     */
    dispose: () => void;
};
//# sourceMappingURL=preprocessing.d.ts.map