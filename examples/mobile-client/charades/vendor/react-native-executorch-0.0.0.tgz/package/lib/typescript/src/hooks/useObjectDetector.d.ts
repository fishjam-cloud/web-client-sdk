import { type ObjectDetectorModel, type BoxFormat } from '../extensions/cv/tasks/objectDetection';
/**
 * React hook to load and run an object detection model.
 *
 * This hook manages downloading (if it's a remote URL) and loading the model
 * file, compiling it, tracking download progress and compilation errors, and
 * cleaning up native model memory when the component unmounts or configuration
 * changes.
 * @category Hooks
 * @typeParam L The type representing the object class labels.
 * @typeParam F The bounding box format.
 * @param config The object detection model configuration.
 * @param options Hook options.
 * @param options.preventLoad If true, prevents downloading and compiling the
 * model.
 * @returns An object containing the model's loading state, error, download
 * progress, and object detection functions.
 */
export declare function useObjectDetector<F extends BoxFormat, L>(config: ObjectDetectorModel<F, L>, options?: {
    preventLoad?: boolean;
}): {
    isReady: boolean;
    error: Error | null;
    downloadProgress: number;
    localPath: string | undefined;
    labels: readonly L[];
    detectObjects: ((input: import("../extensions/cv").ImageBuffer, options?: {
        confidenceThreshold?: number;
        iouThreshold?: number;
    }) => Promise<import("..").ObjectDetection<F, L>[]>) | undefined;
    detectObjectsWorklet: ((input: import("../extensions/cv").ImageBuffer, options?: {
        confidenceThreshold?: number;
        iouThreshold?: number;
    }) => import("..").ObjectDetection<F, L>[]) | undefined;
};
//# sourceMappingURL=useObjectDetector.d.ts.map