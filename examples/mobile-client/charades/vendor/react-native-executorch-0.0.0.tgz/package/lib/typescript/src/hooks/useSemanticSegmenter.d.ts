import { type SemanticSegmentationModel } from '../extensions/cv/tasks/semanticSegmentation';
/**
 * React hook to load and run a semantic segmentation model.
 *
 * This hook manages downloading (if it's a remote URL) and loading the model
 * file, compiling it, tracking download progress and compilation errors, and
 * cleaning up native model memory when the component unmounts or configuration
 * changes.
 * @category Hooks
 * @typeParam L The type representing the segmentation labels.
 * @param config The semantic segmentation model configuration.
 * @param options Hook options.
 * @param options.preventLoad If true, prevents downloading and compiling the
 * model.
 * @returns An object containing the model's loading state, error, download
 * progress, and segmentation functions.
 */
export declare function useSemanticSegmenter<L extends PropertyKey = string>(config: SemanticSegmentationModel<L>, options?: {
    preventLoad?: boolean;
}): {
    isReady: boolean;
    error: Error | null;
    downloadProgress: number;
    localPath: string | undefined;
    segment: ((input: import("../extensions/cv").ImageBuffer, colormap?: Partial<import("..").ColorMap<L>> | undefined) => Promise<import("..").SemanticSegmentationResult<L>>) | undefined;
    segmentWorklet: ((input: import("../extensions/cv").ImageBuffer, colormap?: Partial<import("..").ColorMap<L>> | undefined) => import("..").SemanticSegmentationResult<L>) | undefined;
    labels: readonly L[];
};
//# sourceMappingURL=useSemanticSegmenter.d.ts.map