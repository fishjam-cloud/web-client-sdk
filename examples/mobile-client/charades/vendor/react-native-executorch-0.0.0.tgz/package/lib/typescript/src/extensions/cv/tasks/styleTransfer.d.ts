import type { WorkletRuntime } from 'react-native-worklets';
import type { ImageBuffer } from '../image';
import { type ImagePreprocessorOptions } from './preprocessing';
import { type InterpolationMethod } from '../ops/image';
/**
 * Options for configuring the style transfer preprocessor and postprocessor.
 * @category Types
 */
export type StyleTransferOptions = Omit<ImagePreprocessorOptions, 'resizeMode'> & {
    readonly resizeMode: 'stretch';
    readonly outAlpha: number | number[];
    readonly outBeta: number | number[];
    readonly outInterpolation: InterpolationMethod;
};
/**
 * Model configuration required to instantiate a style transfer task runner.
 * @category Types
 */
export type StyleTransferModel = {
    readonly modelPath: string;
    readonly opts: StyleTransferOptions;
};
/**
 * Creates an image style transfer runner for executing local style transfer models.
 *
 * It validates the model inputs and outputs requirements, pre-allocates
 * the necessary static execution tensors, sets up an image preprocessor, and
 * registers clean disposal hooks to clear all native memory.
 * @category Typescript API
 * @param config Style transfer task configuration containing path and options.
 * @param runtime Optional worklet runtime thread on which to run the model execution.
 * @returns A promise resolving to an object containing style transfer and disposal controls.
 */
export declare function createStyleTransfer(config: StyleTransferModel, runtime?: WorkletRuntime): Promise<{
    /**
     * Releases all allocated native resources.
     */
    dispose: () => void;
    /**
     * Performs asynchronous image style transfer on the given input image.
     * @param input The input image buffer.
     * @returns A promise resolving to the styled image buffer.
     */
    transferStyle: (input: ImageBuffer) => Promise<ImageBuffer>;
    /**
     * Synchronous version of {@link transferStyle} to be executed directly on the
     * caller or worklet thread.
     */
    transferStyleWorklet: (input: ImageBuffer) => ImageBuffer;
}>;
//# sourceMappingURL=styleTransfer.d.ts.map