import type { WorkletRuntime } from 'react-native-worklets';
import type { ImageBuffer } from '../image';
import { type ImagePreprocessorOptions } from './preprocessing';
import { type BoundingBox, type BoxFormat } from '../ops/boxes';
export type { BoxFormat };
/**
 * Options for configuring an instance segmenter preprocessor, label
 * vocabulary, and threshold parameters.
 * @category Types
 * @typeParam F The format type of the bounding box.
 * @typeParam L The label type.
 */
export type InstanceSegmenterOptions<F extends BoxFormat, L> = Omit<ImagePreprocessorOptions, 'resizeMode'> & {
    readonly resizeMode: 'stretch';
    readonly labels: readonly L[];
    readonly boxFormat: F;
    readonly defaultIouThreshold: number;
    readonly defaultMaskThreshold: number;
    readonly defaultConfidenceThreshold: number;
};
/**
 * Model configuration required to instantiate an instance segmenter task runner.
 * @category Types
 * @typeParam F The format type of the bounding box.
 * @typeParam L The label type.
 */
export type InstanceSegmenterModel<F extends BoxFormat, L> = {
    readonly modelPath: string;
    readonly opts: InstanceSegmenterOptions<F, L>;
};
/**
 * Result structure representing a single detected instance with its bounding box,
 * segmentation mask, label, and confidence score.
 * @category Types
 * @typeParam F The format type of the bounding box.
 * @typeParam L The label type.
 */
export type InstanceSegmentationResult<F extends BoxFormat, L> = {
    readonly box: BoundingBox<F>;
    readonly mask: ImageBuffer;
    readonly label: L;
    readonly confidence: number;
};
/**
 * Creates an instance segmenter runner for executing local Instance
 * Segmentation models.
 *
 * It validates model input/output tensor shapes and types, pre-allocates
 * execution and auxiliary tensors, sets up an image preprocessor, and returns
 * execution and resource management controls.
 * @category Typescript API
 * @typeParam F The bounding box format type.
 * @typeParam L The label type.
 * @param config Model configuration containing path and options.
 * @param runtime Optional worklet runtime thread on which to run the model
 * execution.
 * @returns A promise resolving to an object containing instance segmentation
 * and disposal controls.
 */
export declare function createInstanceSegmenter<F extends BoxFormat, L>(config: InstanceSegmenterModel<F, L>, runtime?: WorkletRuntime): Promise<{
    /**
     * Releases all allocated native resources.
     */
    dispose: () => void;
    /**
     * Performs asynchronous instance segmentation on the given input image.
     * @param input The input image buffer.
     * @param options Execution override options.
     * @param options.confidenceThreshold Override for the minimum confidence
     * threshold.
     * @param options.iouThreshold Override for the IoU threshold in NMS.
     * @param options.maskThreshold Override for the mask binarization threshold.
     * @returns A promise resolving to a list of detected instances.
     */
    segmentInstances: (input: ImageBuffer, options?: {
        confidenceThreshold?: number;
        iouThreshold?: number;
        maskThreshold?: number;
    }) => Promise<InstanceSegmentationResult<F, L>[]>;
    /**
     * Synchronous version of {@link segmentInstances} to be executed directly on
     * the caller or worklet thread.
     */
    segmentInstancesWorklet: (input: ImageBuffer, options?: {
        confidenceThreshold?: number;
        iouThreshold?: number;
        maskThreshold?: number;
    }) => InstanceSegmentationResult<F, L>[];
}>;
//# sourceMappingURL=instanceSegmentation.d.ts.map