import type { WorkletRuntime } from 'react-native-worklets';
import type { ImageBuffer } from '../image';
import { type ImagePreprocessorOptions } from './preprocessing';
import type { ResizeMode } from '../ops/image';
import { type Point } from '../ops/points';
import { type BoundingBox, type BoxFormat } from '../ops/boxes';
export type { BoxFormat };
/**
 * Options for configuring a keypoint detector runner.
 * @category Types
 */
export type KeypointDetectorOptions<F extends BoxFormat, L extends PropertyKey> = Omit<ImagePreprocessorOptions, 'resizeMode'> & {
    readonly resizeMode: Exclude<ResizeMode, 'crop'>;
    readonly boxFormat: F;
    readonly landmarks: readonly L[];
    readonly defaultIouThreshold: number;
    readonly defaultConfidenceThreshold: number;
};
/**
 * Model configuration required to instantiate a keypoint detector task runner.
 * @category Types
 */
export type KeypointDetectorModel<F extends BoxFormat, L extends PropertyKey> = {
    readonly modelPath: string;
    readonly opts: KeypointDetectorOptions<F, L>;
};
/**
 * Plural landmarks mapped by their names to coordinates and detection
 * confidence.
 * @category Types
 */
export type Landmarks<L extends PropertyKey> = Record<L, Point & {
    readonly confidence: number;
}>;
/**
 * Result structure representing a single detected bounding box and its
 * associated landmarks.
 * @category Types
 */
export type KeypointDetection<F extends BoxFormat, L extends PropertyKey> = {
    readonly box: BoundingBox<F>;
    readonly confidence: number;
    readonly landmarks: Landmarks<L>;
};
/**
 * Creates an image keypoint detector runner for executing local Keypoint/Pose
 * Detection models.
 *
 * It validates model inputs and output shapes (bounding boxes, confidence
 * scores, and landmark coordinates), pre-allocates execution tensors, setups
 * preprocessing, and sets up lifecycle disposals.
 * @category Typescript API
 * @typeParam F The bounding box format.
 * @typeParam L The landmark labels type.
 * @param config Keypoint task configuration containing path and options.
 * @param runtime Optional worklet runtime thread on which to run the model
 * execution.
 * @returns A promise resolving to an object containing keypoint detection and
 * disposal bindings.
 */
export declare function createKeypointDetector<F extends BoxFormat, L extends PropertyKey>(config: KeypointDetectorModel<F, L>, runtime?: WorkletRuntime): Promise<{
    /**
     * Releases all allocated native resources.
     */
    dispose: () => void;
    /**
     * Performs asynchronous keypoint and bounding box detection on the given
     * input image.
     * @param input The input image buffer.
     * @param options Configuration options for keypoint detection.
     * @param options.confidenceThreshold Minimum confidence score for a
     * detection. If omitted, uses the model default.
     * @param options.iouThreshold Intersection over Union (IoU) threshold for
     * NMS. If omitted, uses the model default.
     * @returns A promise resolving to the list of keypoint detections.
     */
    detectKeypoints: (input: ImageBuffer, options?: {
        confidenceThreshold?: number;
        iouThreshold?: number;
    }) => Promise<KeypointDetection<F, L>[]>;
    /**
     * Synchronous version of {@link detectKeypoints} to be executed directly on
     * the caller or worklet thread.
     */
    detectKeypointsWorklet: (input: ImageBuffer, options?: {
        confidenceThreshold?: number;
        iouThreshold?: number;
    }) => KeypointDetection<F, L>[];
}>;
//# sourceMappingURL=keypointDetection.d.ts.map