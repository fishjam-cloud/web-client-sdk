import { type ClassifierModel } from '../extensions/cv/tasks/classification';
/**
 * React hook to load and run an image classification model.
 *
 * This hook manages downloading (if it's a remote URL) and loading the model
 * file, compiling it, tracking download progress and compilation errors, and
 * cleaning up native model memory when the component unmounts or configuration
 * changes.
 * @category Hooks
 * @typeParam L The type representing the classification labels.
 * @param config The image classification model configuration.
 * @param options Hook options.
 * @param options.preventLoad If true, prevents downloading and compiling the
 * model.
 * @returns An object containing the model's loading state, error, download
 * progress, and classification functions.
 */
export declare function useClassifier<L>(config: ClassifierModel<L>, options?: {
    preventLoad?: boolean;
}): {
    isReady: boolean;
    error: Error | null;
    downloadProgress: number;
    localPath: string | undefined;
    labels: readonly L[];
    classify: ((input: import("../extensions/cv").ImageBuffer, options?: {
        topk?: number;
    }) => Promise<import("..").Classification<L>[]>) | undefined;
    classifyWorklet: ((input: import("../extensions/cv").ImageBuffer, options?: {
        topk?: number;
    }) => import("..").Classification<L>[]) | undefined;
};
//# sourceMappingURL=useClassifier.d.ts.map