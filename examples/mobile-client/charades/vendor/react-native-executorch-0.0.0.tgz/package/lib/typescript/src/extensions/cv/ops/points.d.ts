import type { ResizeMode } from './image';
/**
 * Represents a 2D coordinate point with x and y values.
 * @category Types
 */
export type Point = {
    readonly x: number;
    readonly y: number;
};
/**
 * Helper function to scale a 2D point based on resize mode and resolution
 * changes.
 * @category Utils
 * @param point The original coordinate point to scale.
 * @param opts Options detailing the scaling factors and resize mode.
 * @param opts.from The source bounds (e.g. model input dimensions).
 * @param opts.to The destination bounds (e.g. original image dimensions).
 * @param opts.resizeMode The mode used to resize the image ('letterbox' or
 * 'stretch').
 * @returns The scaled coordinate point.
 */
export declare function scalePoint(point: Point, opts: {
    readonly from: {
        readonly width: number;
        readonly height: number;
    };
    readonly to: {
        readonly width: number;
        readonly height: number;
    };
    readonly resizeMode: Exclude<ResizeMode, 'crop'>;
}): Point;
//# sourceMappingURL=points.d.ts.map