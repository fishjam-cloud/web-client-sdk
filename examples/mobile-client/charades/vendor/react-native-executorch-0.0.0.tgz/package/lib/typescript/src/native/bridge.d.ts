export declare const rnexecutorchJsi: any;
//# sourceMappingURL=bridge.d.ts.map