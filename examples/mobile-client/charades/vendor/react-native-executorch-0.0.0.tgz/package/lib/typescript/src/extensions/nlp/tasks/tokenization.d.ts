import type { WorkletRuntime } from 'react-native-worklets';
/**
 * Loads a tokenizer and exposes its operations with lifetime management for the
 * `useTokenizer` hook.
 * @category Typescript API
 * @param tokenizerPath Absolute local path to a `tokenizer.json` file.
 * @param runtime Optional worklet runtime thread to run the tokenizer on.
 * @returns A promise resolving to the tokenizer operations and a `dispose`
 * handle that releases the native tokenizer.
 */
export declare function createTokenizer(tokenizerPath: string, runtime?: WorkletRuntime): Promise<{
    encode: (text: string) => Promise<number[]>;
    decode: (tokens: number[], skipSpecialTokens?: boolean | undefined) => Promise<string>;
    getVocabSize: () => number;
    idToToken: (id: number) => string;
    tokenToId: (token: string) => number;
    dispose: () => void;
}>;
//# sourceMappingURL=tokenization.d.ts.map