import type { WorkletRuntime } from 'react-native-worklets';
import type { ImageBuffer } from '../image';
import { type ImagePreprocessorOptions } from './preprocessing';
import { type InterpolationMethod } from '../ops/image';
/**
 * Options for configuring a semantic segmenter preprocessor and label
 * vocabulary.
 * @category Types
 */
export type SemanticSegmentationOptions<L> = Omit<ImagePreprocessorOptions, 'resizeMode'> & {
    readonly resizeMode: 'stretch';
    readonly outInterpolation: InterpolationMethod;
    readonly labels: readonly L[];
};
/**
 * Model configuration required to instantiate a segmenter task runner.
 * @category Types
 */
export type SemanticSegmentationModel<L> = {
    readonly modelPath: string;
    readonly opts: SemanticSegmentationOptions<L>;
};
/**
 * Maps each class label to its assigned RGBA color.
 * @category Types
 */
export type ColorMap<L extends PropertyKey> = Record<L, [number, number, number, number]>;
/**
 * Result structure representing the output of a semantic segmentation task.
 * @category Types
 */
export type SemanticSegmentationResult<L extends PropertyKey> = {
    buffer: ImageBuffer;
    colormap?: ColorMap<L>;
};
/**
 * Creates a semantic segmenter runner for executing local Semantic Segmentation
 * models.
 *
 * It validates the model inputs and outputs, asserts that the labels array
 * length matches the model's output vocabulary size, pre-allocates the
 * necessary static execution tensors, sets up an image preprocessor, and
 * registers clean disposal hooks to clear all native memory.
 * @category Typescript API
 * @typeParam L The type representing the segmentation labels.
 * @param config Segmenter task configuration containing path and options.
 * @param runtime Optional worklet runtime thread environment context.
 * @returns A promise resolving to an object containing segmentation and
 * disposal controls.
 */
export declare function createSemanticSegmenter<L extends PropertyKey = string>(config: SemanticSegmentationModel<L>, runtime?: WorkletRuntime): Promise<{
    /**
     * Releases all allocated native resources.
     */
    dispose: () => void;
    /**
     * Runs semantic segmentation asynchronously.
     *
     * For models returning logits for all classes, this performs an argmax over
     * the class dimensions to identify the highest-probability class per pixel,
     * then maps each class index to an RGBA color from the colormap. The final
     * mapped colormap is returned in the result.
     *
     * For models returning only a single logit value for the positive class, this
     * applies a sigmoid activation, normalizes the probability values to
     * grayscale (0-255), and converts the output to a grayscale RGBA mask. No
     * colormap is applied, and the colormap in the result is undefined.
     * @param input The input image buffer to segment.
     * @param colormap Optional partial color mapping overrides for labels
     * (applicable only for multi-class models). If not provided, a default
     * colormap is automatically generated with distinct, high-contrast colors
     * (with the first label defaulting to transparent). If a partial map is
     * provided, any labels omitted from it will default to being rendered as
     * fully transparent.
     * @returns A promise resolving to the segmentation result.
     */
    segment: (input: ImageBuffer, colormap?: Partial<ColorMap<L>>) => Promise<SemanticSegmentationResult<L>>;
    /**
     * Runs semantic segmentation synchronously.
     * @see {@link segment} for details.
     */
    segmentWorklet: (input: ImageBuffer, colormap?: Partial<ColorMap<L>>) => SemanticSegmentationResult<L>;
}>;
//# sourceMappingURL=semanticSegmentation.d.ts.map