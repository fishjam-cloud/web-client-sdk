/**
 * React hook to load and use a HuggingFace tokenizer.
 *
 * This hook manages downloading the `tokenizer.json` file (if it's a remote
 * URL), loading it natively, tracking download progress and load errors, and
 * cleaning up native memory when the component unmounts or the source changes.
 * @category Hooks
 * @param tokenizerPath A remote URL or local path to a `tokenizer.json` file.
 * @param options Hook options.
 * @param options.preventLoad If true, prevents downloading and loading the
 * tokenizer.
 * @returns An object containing the tokenizer's loading state, error, download
 * progress, and tokenization functions.
 */
export declare function useTokenizer(tokenizerPath: string, options?: {
    preventLoad?: boolean;
}): {
    isReady: boolean;
    error: Error | null;
    downloadProgress: number;
    localPath: string | undefined;
    encode: ((text: string) => Promise<number[]>) | undefined;
    decode: ((tokens: number[], skipSpecialTokens?: boolean | undefined) => Promise<string>) | undefined;
    getVocabSize: (() => number) | undefined;
    idToToken: ((id: number) => string) | undefined;
    tokenToId: ((token: string) => number) | undefined;
};
//# sourceMappingURL=useTokenizer.d.ts.map